## References

1. Somewhat Practical Fully Homomorphic Encryption (<https://eprint.iacr.org/2012/144>)
2. Fully Homomorphic Encryption without Bootstrapping (<https://eprint.iacr.org/2011/277>)
3. Efficient Homomorphic Conversion Between (Ring) LWE Ciphertexts (<https://eprint.iacr.org/2020/015>)
4. HERMES: Efficient Ring Packing using MLWE Ciphertexts and Application to Transciphering (<https://eprint.iacr.org/2023/1244>)