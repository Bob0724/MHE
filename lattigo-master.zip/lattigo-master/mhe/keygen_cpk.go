package mhe

import (
	"io"

	"github.com/tuneinsight/lattigo/v5/core/rlwe"
	"github.com/tuneinsight/lattigo/v5/ring"
	"github.com/tuneinsight/lattigo/v5/ring/ringqp"
	"github.com/tuneinsight/lattigo/v5/utils/sampling"
)

// PublicKeyGenProtocol is the structure storing the parameters and and precomputations for
// the collective encryption key generation protocol.
// PublicKeyGenProtocol是存储集合加密密钥生成协议的参数和预计算的结构。
type PublicKeyGenProtocol struct {
	params           rlwe.Parameters
	gaussianSamplerQ ring.Sampler
}

// PublicKeyGenShare is a struct storing the PublicKeyGen protocol's share.
// PublicKeyGenShare是一个存储PublicKeyGen协议共享的结构体。
type PublicKeyGenShare struct {
	Value ringqp.Poly
}

// PublicKeyGenCRP is a type for common reference polynomials in the PublicKeyGen protocol.
// publickeygencrp是PublicKeyGen协议中公共引用多项式的类型。
type PublicKeyGenCRP struct {
	Value ringqp.Poly
}

// NewPublicKeyGenProtocol creates a new PublicKeyGenProtocol instance
// NewPublicKeyGenProtocol创建一个新的PublicKeyGenProtocol实例
func NewPublicKeyGenProtocol(params rlwe.ParameterProvider) PublicKeyGenProtocol {
	ckg := PublicKeyGenProtocol{}
	ckg.params = *params.GetRLWEParameters()

	var err error
	prng, err := sampling.NewPRNG()

	// Sanity check, this error should not happen.
	if err != nil {
		panic(err)
	}

	ckg.gaussianSamplerQ, err = ring.NewSampler(prng, ckg.params.RingQ(), ckg.params.Xe(), false)

	// Sanity check, this error should not happen.
	if err != nil {
		panic(err)
	}

	return ckg
}

// AllocateShare allocates the share of the PublicKeyGen protocol.
func (ckg PublicKeyGenProtocol) AllocateShare() PublicKeyGenShare {
	return PublicKeyGenShare{ckg.params.RingQP().NewPoly()}
}

// SampleCRP samples a common random polynomial to be used in the PublicKeyGen protocol from the provided
// common reference string.
// SampleCRP从提供的公共引用字符串中抽取一个公共随机多项式用于PublicKeyGen协议。
func (ckg PublicKeyGenProtocol) SampleCRP(crs CRS) PublicKeyGenCRP {
	crp := ckg.params.RingQP().NewPoly()
	ringqp.NewUniformSampler(crs, *ckg.params.RingQP()).Read(crp)
	return PublicKeyGenCRP{crp}
}

// GenShare generates the party's public key share from its secret key as:
// GenShare从其秘钥生成该方的公钥共享如下:
// crp*s_i + e_i
//
// for the receiver protocol. Has no effect is the share was already generated.
// 对于接收方协议。没有影响的是共享已经生成。
func (ckg PublicKeyGenProtocol) GenShare(sk *rlwe.SecretKey, crp PublicKeyGenCRP, shareOut *PublicKeyGenShare) {
	ringQP := ckg.params.RingQP()

	//gaussianSamplerQ 是一个高斯分布采样器，Read 方法从高斯分布中生成一个随机数，并将其写入 shareOut.Value.Q 中，这是公钥分享的一部分
	ckg.gaussianSamplerQ.Read(shareOut.Value.Q)

	if ringQP.RingP != nil {
		ringQP.ExtendBasisSmallNormAndCenter(shareOut.Value.Q, ckg.params.MaxLevelP(), shareOut.Value.Q, shareOut.Value.P)
	}

	ringQP.NTT(shareOut.Value, shareOut.Value)   //对 shareOut.Value 中的多项式进行数论变换（NTT）。
	ringQP.MForm(shareOut.Value, shareOut.Value) //对 shareOut.Value 中的多项式进行 M 形式转换

	//将 sk.Value 和 crp.Value 中的多项式进行蒙哥马利乘法，然后将结果减去 shareOut.Value 中的多项式，最终将结果存储在 shareOut.Value 中
	ringQP.MulCoeffsMontgomeryThenSub(sk.Value, crp.Value, shareOut.Value)
}

// AggregateShares aggregates a new share to the aggregate key
// AggregateShares将新共享聚合到聚合私钥
// 加到shareOut.Value
func (ckg PublicKeyGenProtocol) AggregateShares(share1, share2 PublicKeyGenShare, shareOut *PublicKeyGenShare) {
	ckg.params.RingQP().Add(share1.Value, share2.Value, shareOut.Value)
}

// GenPublicKey return the current aggregation of the received shares as a bfv.PublicKey.
// GenPublicKey以bfv.PublicKey的形式返回当前接收到的共享的聚合。
func (ckg PublicKeyGenProtocol) GenPublicKey(roundShare PublicKeyGenShare, crp PublicKeyGenCRP, pubkey *rlwe.PublicKey) {
	pubkey.Value[0].Copy(roundShare.Value)
	pubkey.Value[1].Copy(crp.Value)
}

// ShallowCopy creates a shallow copy of PublicKeyGenProtocol in which all the read-only data-structures are
// shared with the receiver and the temporary buffers are reallocated. The receiver and the returned
// PublicKeyGenProtocol can be used concurrently.
//
// ShallowCopy创建一个PublicKeyGenProtocol的浅拷贝，
// 其中所有只读数据结构都与接收方共享，临时缓冲区被重新分配。
// 接收方和返回的PublicKeyGenProtocol可以并发使用。
func (ckg PublicKeyGenProtocol) ShallowCopy() PublicKeyGenProtocol {
	prng, err := sampling.NewPRNG()

	// Sanity check, this error should not happen.
	if err != nil {
		panic(err)
	}

	sampler, err := ring.NewSampler(prng, ckg.params.RingQ(), ckg.params.Xe(), false)

	// Sanity check, this error should not happen.
	if err != nil {
		panic(err)
	}

	return PublicKeyGenProtocol{ckg.params, sampler}
}

// BinarySize returns the serialized size of the object in bytes.
func (share PublicKeyGenShare) BinarySize() int {
	return share.Value.BinarySize()
}

// WriteTo writes the object on an io.Writer. It implements the io.WriterTo
// interface, and will write exactly object.BinarySize() bytes on w.
//
// Unless w implements the buffer.Writer interface (see lattigo/utils/buffer/writer.go),
// it will be wrapped into a bufio.Writer. Since this requires allocations, it
// is preferable to pass a buffer.Writer directly:
//
//   - When writing multiple times to a io.Writer, it is preferable to first wrap the
//     io.Writer in a pre-allocated bufio.Writer.
//   - When writing to a pre-allocated var b []byte, it is preferable to pass
//     buffer.NewBuffer(b) as w (see lattigo/utils/buffer/buffer.go).
func (share PublicKeyGenShare) WriteTo(w io.Writer) (n int64, err error) {
	return share.Value.WriteTo(w)
}

// ReadFrom reads on the object from an io.Writer. It implements the
// io.ReaderFrom interface.
//
// Unless r implements the buffer.Reader interface (see see lattigo/utils/buffer/reader.go),
// it will be wrapped into a bufio.Reader. Since this requires allocation, it
// is preferable to pass a buffer.Reader directly:
//
//   - When reading multiple values from a io.Reader, it is preferable to first
//     first wrap io.Reader in a pre-allocated bufio.Reader.
//   - When reading from a var b []byte, it is preferable to pass a buffer.NewBuffer(b)
//     as w (see lattigo/utils/buffer/buffer.go).
func (share *PublicKeyGenShare) ReadFrom(r io.Reader) (n int64, err error) {
	return share.Value.ReadFrom(r)
}

// MarshalBinary encodes the object into a binary form on a newly allocated slice of bytes.
func (share PublicKeyGenShare) MarshalBinary() (p []byte, err error) {
	return share.Value.MarshalBinary()
}

// UnmarshalBinary decodes a slice of bytes generated by
// MarshalBinary or WriteTo on the object.
func (share *PublicKeyGenShare) UnmarshalBinary(p []byte) (err error) {
	return share.Value.UnmarshalBinary(p)
}
