// Package bignum implements arbitrary precision arithmetic for integers, reals and complex numbers.
package bignum
