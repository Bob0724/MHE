## References

1. Minimax Approximation of Sign Function by Composite Polynomial for Homomorphic Comparison (<https://ieeexplore.ieee.org/abstract/document/9517029>)