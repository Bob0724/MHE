## References

1. Efficient FHEW Bootstrapping with Small Evaluation Keys, and Applications to Threshold Homomorphic Encryption (<https://eprint.iacr.org/2022/198>)